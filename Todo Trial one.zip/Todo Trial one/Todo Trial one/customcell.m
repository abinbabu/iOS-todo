//
//  customcell.m
//  Todo Trial one
//
//  Created by TW-PC3 on 19/06/17.
//  Copyright © 2017 TW-PC3Techware. All rights reserved.
//

#import "customcell.h"

@implementation customcell

@end
