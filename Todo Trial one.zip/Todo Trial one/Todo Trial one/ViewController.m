//
//  ViewController.m
//  Todo Trial one
//
//  Created by TW-PC3 on 19/06/17.
//  Copyright © 2017 TW-PC3Techware. All rights reserved.
//

#import "ViewController.h"
#import "customcell.h"

NSMutableArray *todo;
int n;

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIButton *onSave;
@property (weak, nonatomic) IBOutlet UITableView *todoList;
@property (weak, nonatomic) IBOutlet UIButton *buttonAdd;
@property (weak, nonatomic) IBOutlet UITextField *textField;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self begin];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void) begin{
    todo =[[NSMutableArray alloc]init];
    [_buttonAdd addTarget:self action:@selector(addTodoClick) forControlEvents:UIControlEventTouchUpInside];

}
- (IBAction)save:(UIButton *)sender {
    NSLog(@"%i",n );
    [todo replaceObjectAtIndex:n withObject: _textField.text];
    _textField.text=nil;
    _todoList.reloadData;
    _onSave.hidden=true;
    _buttonAdd.hidden=false;
}
- (IBAction)onEdit:(UIButton *)sender forEvent:(UIEvent *)event {
    
    NSLog(@"touched");
    _onSave.hidden=false;
    _buttonAdd.hidden=true;
    [self editText:[todo objectAtIndex:sender.tag]];
    n= sender.tag;
    NSLog(@"%i",n );
    
}
- (IBAction)remove:(UIButton *)sender forEvent:(UIEvent *)event {
    
    
    [todo removeObjectAtIndex:sender.tag];
    
    _todoList.reloadData;
    
}
-(void) addTodoClick{

    if(_textField.text.length > 0){
        [todo addObject:_textField.text];
        _textField.text=nil;
    }
    _todoList.reloadData;
    
    NSLog (@"Number of elements in array = %lu", [todo count]);
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return todo.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    customcell *cell = [tableView dequeueReusableCellWithIdentifier:@"customCell"];
    if (!cell) {
        cell = [[customcell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"customCell"];
    }
    cell.todoList.text = [todo objectAtIndex:indexPath.row];
    cell.RemoveFromList.tag = indexPath.row;
    cell.editFromList.tag = indexPath.row;
    return cell;
}
-(void) editText : (NSString *)text{
    
     _textField.text = text;
    
}


@end
