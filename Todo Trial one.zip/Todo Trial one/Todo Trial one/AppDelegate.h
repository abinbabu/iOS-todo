//
//  AppDelegate.h
//  Todo Trial one
//
//  Created by TW-PC3 on 19/06/17.
//  Copyright © 2017 TW-PC3Techware. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

