//
//  customcell.h
//  Todo Trial one
//
//  Created by TW-PC3 on 19/06/17.
//  Copyright © 2017 TW-PC3Techware. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface customcell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *RemoveFromList;
@property (weak, nonatomic) IBOutlet UIButton *editFromList;
@property (weak, nonatomic) IBOutlet UILabel *todoList;
@end
