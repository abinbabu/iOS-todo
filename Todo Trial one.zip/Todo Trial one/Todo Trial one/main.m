//
//  main.m
//  Todo Trial one
//
//  Created by TW-PC3 on 19/06/17.
//  Copyright © 2017 TW-PC3Techware. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
